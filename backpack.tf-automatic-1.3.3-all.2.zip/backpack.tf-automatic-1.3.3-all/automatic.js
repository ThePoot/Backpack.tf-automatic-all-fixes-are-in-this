require('./app/version-check'); // v4.0.0
require('./app/automatic'); // main
